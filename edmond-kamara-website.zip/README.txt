EDMOND KAMARA WEBSITE

Files:
- index.html
- assets/profile.png

To publish without Netlify:
1. Create/sign in to a GitHub account.
2. Create a public repository named: edmondkamara.github.io
3. Upload index.html and the assets folder.
4. In Settings > Pages, choose Deploy from branch, main, /root.
5. Your site will be available at:
   https://edmondkamara.github.io

You can later connect a custom domain such as edmondkamara.com.
